def calcular_valor_futuro(P, i, n):
    return P * (1 + i) ** n

def calcular_valor_presente(M, i, n):
    return M / (1 + i) ** n

P1 = 1200
i1 = 0.09
n1 = 10

P2 = 2000
i2 = 0.10
n2 = 8

montante_fulana = calcular_valor_futuro(P1, i1, n1)
montante_ciclana = calcular_valor_futuro(P2, i2, n2)

mais_rentavel = "Fulana" if montante_fulana > montante_ciclana else "Ciclana"

M1 = 12000
i3 = 0.09
n3 = 10

M2 = 14000
i4 = 0.10
n4 = 12

presente_fulano = calcular_valor_presente(M1, i3, n3)
presente_ciclano = calcular_valor_presente(M2, i4, n4)

mais_rentavel_presente = "Fulano" if presente_fulano < presente_ciclano else "Ciclano"

print("--- Atividade 01 ---")
print(f"Montante de Joana Fulana: ${montante_fulana:.2f}")
print(f"Montante de Joana Ciclana: ${montante_ciclana:.2f}")
print(f"Mais rentável: Joana {mais_rentavel}")

print("\n--- Atividade 02 ---")
print(f"Valor presente para João Fulano: ${presente_fulano:.2f}")
print(f"Valor presente para João Ciclano: ${presente_ciclano:.2f}")
print(f"Mais rentável: João {mais_rentavel_presente}")
